from microdot import Microdot, Response
import asyncio
import time
from html_page import HTML_PAGE
from serial_io import write_command
import camera_ai

app = Microdot()
Response.default_content_type = 'text/html'

# --- WATCHDOG VARIABLE ---
last_motor_time = 0

# --- Wheel parameters ---
WHEEL_RADIUS = 0.03   # ???? (3cm)
TICKS_PER_REV = 360   # encoder ticks ??? 1 ???

@app.route('/')
async def index(request):
    return HTML_PAGE


# ===============================
# MOVE ONCE
# ===============================
@app.route('/move_once')
async def move_once(request):
    global last_motor_time
    last_motor_time = time.time()

    l = request.args.get('l', '0')
    r = request.args.get('r', '0')
    t = request.args.get('t', '250')

    cmd = f"o {l} {r}\n"

    await asyncio.get_running_loop().run_in_executor(
        None, write_command, cmd, False
    )

    await asyncio.sleep(float(t)/1000)

    await asyncio.get_running_loop().run_in_executor(
        None, write_command, "o 0 0\n", False
    )

    return 'OK'


# ===============================
# CONTINUOUS MOTOR
# ===============================
@app.route('/motor')
async def motor(request):

    global last_motor_time
    last_motor_time = time.time()

    l = request.args.get('l', '0')
    r = request.args.get('r', '0')

    cmd = f"o {l} {r}\n"

    await asyncio.get_running_loop().run_in_executor(
        None, write_command, cmd, False
    )

    return 'OK'


# ===============================
# LED
# ===============================
@app.route('/led')
async def led(request):

    pin = request.args.get('pin', '2')
    state = request.args.get('state', '0')

    cmd = f"l {pin} {state}\n"

    resp = await asyncio.get_running_loop().run_in_executor(
        None, write_command, cmd
    )

    return resp


# ===============================
# SERVO
# ===============================
@app.route('/servo')
async def servo(request):

    sid = request.args.get('id', '0')
    angle = request.args.get('angle', '0')

    cmd = f"s {sid} {angle}\n"

    resp = await asyncio.get_running_loop().run_in_executor(
        None, write_command, cmd
    )

    return resp


# ===============================
# ENCODER + DISTANCE
# ===============================
@app.route('/encoders')
async def encoders(request):

    resp = await asyncio.get_running_loop().run_in_executor(
        None, write_command, "e\n"
    )

    try:

        left, right = resp.split()

        left = int(left)
        right = int(right)

        # distance calculation
        distance_l = (left / TICKS_PER_REV) * (2 * 3.1416 * WHEEL_RADIUS)
        distance_r = (right / TICKS_PER_REV) * (2 * 3.1416 * WHEEL_RADIUS)

        return {
            "left": left,
            "right": right,
            "distance_l": round(distance_l, 3),
            "distance_r": round(distance_r, 3)
        }

    except:

        return {
            "left": 0,
            "right": 0,
            "distance_l": 0,
            "distance_r": 0
        }


# ===============================
# RESET ENCODER
# ===============================
@app.route('/reset')
async def reset(request):

    await asyncio.get_running_loop().run_in_executor(
        None, write_command, "r\n"
    )

    return 'OK'


# ===============================
# VIDEO STREAM
# ===============================
@app.route('/video')
async def video(request):

    return Response(
        body=camera_ai.generate_frames(),
        headers={
            'Content-Type': 'multipart/x-mixed-replace; boundary=frame'
        }
    )


# ===============================
# AI ON / OFF
# ===============================
@app.route('/toggle_ai')
async def toggle_ai(request):

    state = request.args.get('enabled')

    is_enabled = (state == 'true')

    camera_ai.set_ai_enabled(is_enabled)

    return {
        'status': 'success',
        'ai_enabled': is_enabled
    }

