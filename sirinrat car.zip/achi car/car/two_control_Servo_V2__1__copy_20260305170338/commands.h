#ifndef COMMANDS_H
#define COMMANDS_H

// ===== wheel side =====
#define LEFT  0
#define RIGHT 1

// ===== serial commands =====
#define GET_BAUDRATE   'b'
#define READ_ENCODERS  'e'
#define RESET_ENCODERS 'r'
#define MOTOR_RAW_PWM  'o'
#define SERVO_MOTOR    's'

#endif
