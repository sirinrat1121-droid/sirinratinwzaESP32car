#include "servos.h"
#include <ESP32Servo.h>

volatile int servoTarget = 90;
Servo myservo;

void initServos() {
  ESP32PWM::allocateTimer(3);
  myservo.setPeriodHertz(50);
  myservo.attach(SERVO_PIN, 500, 2400);
  myservo.write(servoTarget);
}

void Servo_do(float degree) {
  myservo.write(degree);
}
